<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News Website</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header class="bg-danger text-white py-2">
        <div class="container col-12 bg-white">
            <div class="row">
                <div class="col-12 text-center">
                    <img src="images/bz-logo.svg" alt="Logo" >
                </div>
            </div>
            <nav class="navbar navbar-expand-md navbar-dark justify-content-center ">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="kategorija.php?id=Kultura">Kultura</a></li>
                    <li class="nav-item"><a class="nav-link" href="kategorija.php?id=Glazba">Glazba</a></li>
                    <li class=""nav-item dropdown">
          <a class="nav-link" href="prijava.html">Administracija</a>
          <ul class="dropdown_content">
            <li><a href="prijava.html">Prijava</a></li>
            <li><a href="registracija.php">Registracija</a></li>
          </ul>
        </li>
            </ul>
            </nav>
        </div>
</header>
<div class = "container">
  <?php
      include "connect.php";
      if(isset($_GET['id'])){
        $article_id = $_GET['id'];

        if($dbc){
          $query_article = "SELECT * FROM clanak WHERE id = $article_id";
          $result = mysqli_query($dbc,$query_article);
          if($result){
            while($row = mysqli_fetch_array($result)){
              $kategorija = $row['kategorija'];
              $naslov  = $row['naslov_vijesti'];
              $sazetak = $row['kratki_sazetak_vijesti'];
              $vrijeme = $row['datum'];
              $slika = $row['slika'];
              $vijest = $row['sadrzaj_vijesti'];
              echo "<article class ='single_article'>";
                echo "<p>$kategorija</p>";
                echo "<h1>$naslov</h1>";
                echo "<br><br>";
                echo "<h2 class='fs-5'>$sazetak</h2>";
                echo "<br><br>";
                echo "<time>$vrijeme</time>";
                echo "<br><br>";
                echo "<img class='img-fluid mb-2' src=images/$slika>";
                echo "<br><br>";
                echo "<p>$vijest</p>";
              echo "</article>";
            }
          }
        }
      }
    ?>
  </div>
    </footer>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
