<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News Website</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header class="bg-danger text-white py-2">
        <div class="container col-12 bg-white">
            <div class="row">
                <div class="col-12 text-center">
                    <img src="images/bz-logo.svg" alt="Logo" >
                </div>
            </div>
            <nav class="navbar navbar-expand-md navbar-dark justify-content-center ">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="kategorija.php?id=Kultura">Kultura</a></li>
                    <li class="nav-item"><a class="nav-link" href="kategorija.php?id=Glazba">Glazba</a></li>
                    <li class=""nav-item dropdown">
          <a class="nav-link" href="prijava.html">Administracija</a>
          <ul class="dropdown_content">
            <li><a href="prijava.html">Prijava</a></li>
            <li><a href="registracija.php">Registracija</a></li>
          </ul>
        </li>
            </ul>
            </nav>
        </div>
</header>
<div class="forma">
    <form action="" method="post" id="registrationForm">
        <label for="ime">Unesite vaše ime:</label>
        <br>
        <input type="text" name="ime" required>
        <br>
        <label for="prezime">Unesite vaše prezime:</label>
        <br>
        <input type="text" name="prezime" required>
        <br>
        <label for="korisnicko_ime">Unesite korisničko ime:</label>
        <br>
        <span id="korisnicko_ime_poruka"></span>
        <br>
        <input type="text" name="korisnicko_ime" required>
        <br>
        <label for="lozinka">Unesite lozinku:</label>
        <br>
        <input type="password" name="lozinka" required>
        <br>
        <br>
      <div class="btn-container">
        <input type="submit" value="Registracija">
      </div>
    </form>
  </div>

  <?php
    include 'connect.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
      $ime = $_POST['ime'];
      $prezime = $_POST['prezime'];
      $korisnicko_ime = $_POST['korisnicko_ime'];
      $lozinka = $_POST['lozinka'];
      $razina = 0;

      $hashirana_lozinka = password_hash($lozinka, CRYPT_BLOWFISH);

      $stmt = mysqli_stmt_init($dbc);
      $query = "SELECT * FROM korisnik WHERE korisnicko_ime = ?";
      if (mysqli_stmt_prepare($stmt, $query)) {
        mysqli_stmt_bind_param($stmt, 's', $korisnicko_ime);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
      }
      if (mysqli_stmt_num_rows($stmt) > 0) {
        echo "<script>
                document.getElementById('korisnicko_ime_poruka').innerHTML = 'Korisničko ime je zauzeto';
                document.getElementById('korisnicko_ime_poruka').style.color = 'red';
              </script>";
      } else {
        echo"<p class='ispis_poruke'>Registracija uspješna</p>";
        $query_insert = "INSERT INTO korisnik (ime, prezime, korisnicko_ime, lozinka, razina) VALUES (?, ?, ?, ?, ?)";
        if (mysqli_stmt_prepare($stmt, $query_insert)) {
          mysqli_stmt_bind_param($stmt, 'ssssd', $ime, $prezime, $korisnicko_ime, $hashirana_lozinka, $razina);
          mysqli_stmt_execute($stmt);
        }
      }
      mysqli_stmt_close($stmt);
    }

    mysqli_close($dbc);
  ?>

<footer class="footer bg-dark text-white">
    <div class="container text-center py-3">
        <p class="mb-0" id="footertext">Petra Štetić &nbsp pstetic@tvz.hr &nbsp 2024</p>
    </div>
</footer>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>