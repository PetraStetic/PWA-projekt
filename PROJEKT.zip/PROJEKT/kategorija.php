<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News Website</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="bg-danger text-white py-2">
        <div class="container col-12 bg-white">
            <div class="row">
                <div class="col-12 text-center">
                    <img src="images/bz-logo.svg" alt="Logo" >
                </div>
            </div>
            <nav class="navbar navbar-expand-md navbar-dark justify-content-center ">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">Kultura</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">Glazba</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">Administracija</a></li>
                </ul>
            </nav>
        </div>
</header>

<div class="clanci">
    <div class="container">
      <section class="row">
        <?php
        include 'connect.php';
        if ($dbc) {
            $kategorija = $_GET['id'];
            echo "<h1>" . ucfirst(str_replace('_', ' ', $kategorija)) . "</h1>";

            $query = "SELECT * FROM clanak WHERE kategorija = '$kategorija' AND arhiva = 0 ORDER BY datum DESC";
            $result = mysqli_query($dbc, $query) or die('Error querying database');

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_array($result)) {
                    $slika = $row['slika'];
                    $naslov = $row['naslov_vijesti'];
                    $sazetak = $row['kratki_sazetak_vijesti'];
                    $vrijeme = $row['datum'];

                    echo "<a href='clanak.php?id={$row['id']}' class='col-lg-3 col-md-6 col-sm-12'>";
                    echo "<article class='article'>";
                    echo "<img class='img-fluid mb-2' src='images/$slika' alt=''>";
                    echo "<h2 class='fs-5'>$naslov</h2>";
                    echo "<p>$sazetak</p>";
                    echo "<time>$vrijeme</time>";
                    echo "</article>";
                    echo "</a>";
                }
            } else {
                echo "Nema dostupnih članaka.";
            }

            mysqli_close($dbc);
        } else {
            echo "Ne može se pristupiti podacima: " . mysqli_error($dbc);
        }
        ?>
      </section>
    </div>
  </div>

  <footer class="footer bg-dark text-white">
    <div class="container text-center py-3">
        <p class="mb-0" id="footertext">Petra Štetić &nbsp pstetic@tvz.hr &nbsp 2024</p>
    </div>
</footer>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>