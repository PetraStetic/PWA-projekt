<!DOCTYPE html>
<html lang="hr">
<?php

include "connect.php";

$slika = "";
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['posalji'])) {
  if(isset($_POST['naslov'])){
    $naslov=$_POST['naslov'];
  }
  if(isset($_POST['kategorija'])){
    $kategorija = $_POST['kategorija'];
  }
  if(isset($_POST['sazetak'])){
    $sazetak=$_POST['sazetak'];
  }
  if(isset($_POST['vijesti'])){
    $vijesti=$_POST['vijesti'];
  }
  if (isset($_FILES['slika'])) {
    $slika = basename($_FILES['slika']['name']);
    $target_dir = 'images/'.$slika;
    move_uploaded_file($_FILES["slika"]["tmp_name"], $target_dir);
  }
  $datum_vrijeme = date("Y-m-d H:i:s", time());

  if(isset($_POST['arhiva'])){
     $arhiva=1; 
    }else{ 
      $arhiva=0; 
    }
}
if(isset($_POST['posalji'])){
  $query_insert = "INSERT INTO clanak(kategorija,naslov_vijesti,kratki_sazetak_vijesti,datum,slika,sadrzaj_vijesti,arhiva) 
  VALUES ('$kategorija','$naslov','$sazetak','$datum_vrijeme','$slika','$vijesti','$arhiva')";

  $result_insert = mysqli_query($dbc, $query_insert) or die('Error querying databese.');
}

if(isset($_POST['izmjeni'])){ 
  if(isset($_POST['naslov'])){
    $naslov=$_POST['naslov'];
  }
  if(isset($_POST['kategorija'])){
    $kategorija = $_POST['kategorija'];
  }
  if(isset($_POST['sazetak'])){
    $sazetak=$_POST['sazetak'];
  }
  if(isset($_POST['vijesti'])){
    $vijesti=$_POST['vijesti'];
  }
  if (isset($_FILES['slika'])) {
    $slika = basename($_FILES['slika']['name']);
    $target_dir = 'images/'.$slika;
    move_uploaded_file($_FILES["slika"]["tmp_name"], $target_dir);
  }else{
    $query_old_image = "SELECT slika FROM clanak WHERE id={$_POST['id']}";
    $result_old_image = mysqli_query($dbc, $query_old_image);
    $row = mysqli_fetch_assoc($result_old_image);
    $slika = $row['slika'];
  }
  $datum_vrijeme = date("Y-m-d H:i:s", time());

  if(isset($_POST['arhiva'])){
     $arhiva=1; 
    }else{ 
      $arhiva=0; 
    }
  $id_uredi=$_POST['id']; 
  $query_update = "UPDATE clanak SET kategorija='$kategorija',	naslov_vijesti='$naslov', kratki_sazetak_vijesti = '$sazetak', datum='$datum_vrijeme', slika = '$slika', 	sadrzaj_vijesti = '$vijesti', arhiva='$arhiva'
   WHERE id=$id_uredi"; 
  $result_update = mysqli_query($dbc, $query_update); 
}

if(isset($_POST['izbrisi'])){
  $id = $_POST['id'];
  $query_delete = "DELETE FROM clanak WHERE id=$id";
  $result_delete =mysqli_query($dbc,$query_delete) or die('Error querying databese.');
}
mysqli_close($dbc);
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News Website</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>
<header class="bg-danger text-white py-2">
    <div class="container col-12 bg-white">
        <div class="row">
            <div class="col-12 text-center">
                <img src="images/bz-logo.svg" alt="Logo" >
            </div>
        </div>
        <nav class="navbar navbar-expand-md navbar-dark justify-content-center ">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Kultura</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Glazba</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Administracija</a></li>
            </ul>
        </nav>
    </div>
</header>

  <?php if(isset($_POST['posalji'])||isset($_POST['izmjeni'])){?>
  <div class = "container m-10 py-10">
    <article id="clanak_forma">
      <p>
        <?php echo $kategorija; ?>
      </p>
      <br>
      <h1>
        <?php echo $naslov; ?>
      </h1>
      <br>
      <h2>
        <?php echo $sazetak; ?>
      </h2>
      <br>
      <time>
        <?php echo $datum_vrijeme; ?>
      </time>
      <br>
      <?php echo "<img src='images/$slika'"; ?>
      <br><br><br>
      <p>
        <?php echo $vijesti; ?>
      </p>
    </article>
  </div>
  <?php }else{
    echo "<p class='ispis_poruke'>Uspješno ste obrisali članak</p>";
  }
  ?>

<footer class="footer bg-dark text-white">
    <div class="container text-center py-3">
        <p class="mb-0" id="footertext">Petra Štetić &nbsp pstetic@tvz.hr &nbsp 2024</p>
    </div>
</footer>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>