<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News Website</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="bg-danger text-white py-2">
        <div class="container col-12 bg-white">
            <div class="row">
                <div class="col-12 text-center">
                    <img src="images/bz-logo.svg" alt="Logo" >
                </div>
            </div>
            <nav class="navbar navbar-expand-md navbar-dark justify-content-center ">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="kategorija.php?id=Kultura">Kultura</a></li>
                    <li class="nav-item"><a class="nav-link" href="kategorija.php?id=Glazba">Glazba</a></li>
                    <li class=""nav-item dropdown">
          <a class="nav-link" href="prijava.html">Administracija</a>
          <ul class="dropdown_content">
            <li><a href="prijava.html">Prijava</a></li>
            <li><a href="registracija.php">Registracija</a></li>
          </ul>
        </li>
            </ul>
            </nav>
        </div>
</header>
<main class="container col-8 my-4">
    <section class="mb-4">
        <h2 class="bg-warning text-white p-3">KULTURA</h2>
        <div class="row">
            <?php
            include 'connect.php';
            if($dbc){
                $query_kultura = "SELECT * FROM clanak WHERE kategorija = 'Kultura' AND arhiva = 0 ORDER BY datum DESC LIMIT 4";
                $result_kultura = mysqli_query($dbc, $query_kultura) or die('Error querying database');
                
                if(mysqli_num_rows($result_kultura) > 0) {
                    while($row = mysqli_fetch_array($result_kultura)){
                        $slika = $row['slika'];
                        $naslov = $row['naslov_vijesti'];
                        $sazetak  = $row['kratki_sazetak_vijesti'];
                        $vrijeme  = $row['datum'];
            
                        echo "<a href='clanak.php?id={$row['id']}' class='col-lg-3 col-md-6 col-sm-12'>";
                        echo "<article class='article'>";
                            echo "<img class='img-fluid mb-2' src='images/$slika' alt=''>";
                            echo "<h2 class='fs-5'>$naslov</h2>";
                            echo "<p>$sazetak</p>";
                            echo "<time>$vrijeme</time>";
                        echo "</article>";
                        echo "</a>";
                    }
                } else {
                    echo "Nema dostupnih članaka.";
                }
                
                mysqli_close($dbc);
            } else {
                echo "Ne može se pristupiti podacima: " . mysqli_error($dbc);
            }
            ?>

            <article class="col-md-4 mb-4">
                <div class="card h-100">
                    <img src="images/ehd_education_logo_2020_pos.jpg" class="card-img-top" alt="Klinsmann Junior">
                    <div class="card-body">
                        <h3>Naslov članka</h3>
                        <h5 class="card-title">Klinsmann Junior (22) verlässt Hertha – aber wohin geht er?</h5>
                    </div>
                </div>
            </article>
            <article class="col-md-4 mb-4">
                <div class="card h-100">
                    <img src="images/betina_film_festival.jpg" class="card-img-top" alt="Paderborn Coach Baumgart">
                    <div class="card-body">
                        <h3>Naslov članka</h3>
                        <h5 class="card-title">Paderborn-Coach Baumgart verrät Startelf für Dresden-Spiel</h5>
                    </div>
                </div>
            </article>
            <article class="col-md-4 mb-4">
                <div class="card h-100">
                    <img src="images/kresimira_gojanovic_veliki_mestar_sviju_hulja__dvoglavi_tus_na_papiru_40_30_cm.jpg" class="card-img-top" alt="Alba Coach">
                    <div class="card-body">
                        <h3>Naslov članka</h3>
                        <h5 class="card-title">Alba-Coach: Deutsche dürfen Platz nicht wegen Passes bekommen</h5>
                    </div>
                </div>
            </article>
        </div>
    </section>
    <section>
        <h2 class="bg-danger text-white p-3">GLAZBA</h2>
        <div class="row">
        <?php
            include 'connect.php';
            if($dbc){
                $query_glazba = "SELECT * FROM clanak WHERE kategorija = 'Ženski nogomet' AND arhiva = 0 ORDER BY datum DESC LIMIT 4";
                $result_glazba = mysqli_query($dbc, $query_glazba) or die('Error querying database');
                
                if(mysqli_num_rows($result_glazba) > 0) {
                    while($row = mysqli_fetch_array($result_glazba)){
                        $slika = $row['slika'];
                        $naslov = $row['naslov_vijesti'];
                        $sazetak  = $row['kratki_sazetak_vijesti'];
                        $vrijeme  = $row['datum'];
            
                        echo "<a href='clanak.php?id={$row['id']}' class='col-lg-3 col-md-6 col-sm-12'>";
                        echo "<article class='article'>";
                            echo "<img class='img-fluid' src='images/$slika' alt=''>";
                            echo "<h2 class='fs-5'>$naslov</h2>";
                            echo "<p>$sazetak</p>";
                            echo "<time>$vrijeme</time>";
                        echo "</article>";
                        echo "</a>";
                    }
                } else {
                    echo "Nema dostupnih članaka.";
                }
                
                mysqli_close($dbc);
            } else {
                echo "Ne može se pristupiti podacima: " . mysqli_error($dbc);
            }
            ?>
            <article class="col-md-4 mb-4">
                <div class="card h-100">
                    <img src="images/The_Smile_Pula_1200x628-370x224.png" class="card-img-top" alt="Sandra Maischberger">
                    <div class="card-body">
                        <h3>Naslov članka</h3>
                        <h5 class="card-title">In Sachen Mode hat bei Sandra Maischberger ihr Mann die Hosen an!</h5>
                    </div>
                </div>
            </article>
            <article class="col-md-4 mb-4">
                <div class="card h-100">
                    <img src="images/Untitled-design-18-370x224.png" class="card-img-top" alt="Harald Juhnke">
                    <div class="card-body">
                        <h3>Naslov članka</h3>
                        <h5 class="card-title">ARD verschiebt Film über Harald Juhnke</h5>
                    </div>
                </div>
            </article>
            <article class="col-md-4 mb-4">
                <div class="card h-100">
                    <img src="images/Lollipop-Summer-Cup-FB-370x224.png" class="card-img-top" alt="Mariella Ahrens">
                    <div class="card-body">
                        <h3>Naslov članka</h3>
                        <h5 class="card-title">„Meine Töchter sollen wie ich unabhängig durchs Leben gehen!“</h5>
                    </div>
                </div>
            </article>
        </div>
    </section>
</main>
<footer class="footer bg-dark text-white">
    <div class="container text-center py-3">
        <p class="mb-0" id="footertext">Petra Štetić &nbsp pstetic@tvz.hr &nbsp 2024</p>
    </div>
</footer>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
